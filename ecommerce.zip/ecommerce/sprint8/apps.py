from django.apps import AppConfig


class Sprint8Config(AppConfig):
    name = 'sprint8'
